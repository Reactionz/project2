import java.util.Random;

public class Member implements Comparable<Member>  {
    static Random rnd = new Random();
    public int compareTo( Member  m ) {
	//int mID = (Member m).
	return ID - m.ID ;
    }
    public Member () {
	generate();
    }	
    
      public void generate() {
	  // ID = rnd.nextInt( 999999999 - 100000000 ) + 100000000;
	  ID = rnd.nextInt( 999999999 - 100000000 ) + 1000000;
	  firstName = Names.firstName[ rnd.nextInt(180)];
	  lastName = Names.lastName[ rnd.nextInt(180)];

     }
     public String toString() {
	 return String.format("%03d-%02d-%04d %10s %-10s", ID /1000000, 
	    ID / 10000 % 100, ID % 10000, firstName, lastName);
     }
     /*
     public String toString( boolean );
     public int    compareTo(Member);
     public String htmlRow();
     public String htmlColumns();
     other necessay methods....
    */
    
     protected String firstName = null, lastName = null;
     int ID = 0;
}


